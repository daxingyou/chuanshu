﻿$(document).ready(function () {
    $(".nav_main ul li").click(function () {
        $(this).siblings().find("span").css("display", "none");
        $(this).find("span").css("display", "block");
    })

    var top = document.getElementById("navigation").offsetTop + 0;
    var p1 = $("#p1_bg").offset().top;
    var p2 = $("#p2_bg").offset().top;
    var p3 = $("#p4_bg").offset().top;//$("#p3_bg").offset().top;
    var p4 = $("#p5_bg").offset().top;
    //var p5 = $("#p6_bg").offset().top;
    //alert(top);
    $(window).scroll(function () {
        if ($(window).scrollTop() > top) {
            $("#navigation").addClass("float_login_fix");
            $(".nav_hidden").show();
        } else {
            $("#navigation").removeClass("float_login_fix");
            $(".nav_hidden").hide();
            $(".nav_main ul li").find("span").css("display", "none");
        }
        if ($(window).scrollTop() > top && $(window).scrollTop() < p1 + 100) {
            $(".nav_main ul li span").css("display", "none");
            $(".nav_main ul li:eq(0) span").css("display", "block");
        }
        else if ($(window).scrollTop() > p1 && $(window).scrollTop() < p2 + 100) {
            $(".nav_main ul li span").css("display", "none");
            $(".nav_main ul li:eq(1) span").css("display", "block");
        } else if ($(window).scrollTop() > p2 && $(window).scrollTop() < p3 + 100) {
            $(".nav_main ul li span").css("display", "none");
            $(".nav_main ul li:eq(2) span").css("display", "block");
        } else if ($(window).scrollTop() > p3 && $(window).scrollTop() < p4 + 100) {
            $(".nav_main ul li span").css("display", "none");
            $(".nav_main ul li:eq(3) span").css("display", "block");
        }
        //else if ($(window).scrollTop() > p4 && $(window).scrollTop() < p5 + 100) {
        //    $(".nav_main ul li span").css("display", "none");
        //    $(".nav_main ul li:eq(4) span").css("display", "block");
        //}
    });

    $('#index_float1').jqFloat({
        width: 0,
        height: 50,
        speed: 1800
    });
    $('#index_float2').jqFloat({
        width: 0,
        height: 50,
        speed: 1800
    });
    $('#index_float3').jqFloat({
        width: 0,
        height: 50,
        speed: 2200
    });
    $('#index_float4').jqFloat({
        width: 0,
        height: 50,
        speed: 1800
    });
    $('#index_float5').jqFloat({
        width: 0,
        height: 50,
        speed: 2200
    });
    $('#index_float6').jqFloat({
        width: 0,
        height: 50,
        speed: 2200
    });
    $('#index_float7').jqFloat({
        width: 0,
        height: 50,
        speed: 2200
    });
    $('#index_float8').jqFloat({
        width: 0,
        height: 50,
        speed: 2200
    });
    $('#index_float9').jqFloat({
        width: 0,
        height: 50,
        speed: 2200
    });
    $('#index_float10').jqFloat({
        width: 0,
        height: 50,
        speed: 2200
    });
    
});