var div = {
	'init':function(){
		var bName;
		var bT;
		if(browser.versions.ios || browser.versions.iPad){
			bName = "Safari";
			bT = "share_ico.gif";
		}else{
			bName = "浏览器";
			bT = "share_ico2.gif";
		}
		$(".games_title").before('<div id="download_box" class="thickdiv" style="display:none"></div> <p class="pa hint" id="hint"></p>');
	},
	'show':function(){
		$("#hint").show();
		$("#download_box").show();
		$(document).click(function(){
	 		div.close();
	 	});
	},	
	'close':function(){
		$("#download_box").hide();
		$("#hint").hide();
	}
};
