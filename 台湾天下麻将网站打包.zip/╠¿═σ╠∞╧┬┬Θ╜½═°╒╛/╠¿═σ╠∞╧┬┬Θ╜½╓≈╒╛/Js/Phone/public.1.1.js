Mobile = function(me) {
	return me = {
			init : function() {
			Mobile.ifIe();
			// slider 滑动图片
			if($("#wrap").length > 0){
				var slider = new Swipe(document.getElementById('wrap'), {
					callback : function(e, pos) {
						pos + 1;
					}
				});
			}
		},
		ifIe : function() {
			if (window.navigator.userAgent.indexOf("MSIE") >= 1) {
				$("#default_style").attr('href','http://css.gc73.com.cn/mobile/game_v3_pc.css'); 
			}
		},
		wxShare : function(shareTxtArray , title , imgUrl) {
			var randInt = Math.ceil(Math.random() * 100);	
			randInt = randInt % shareTxtArray.length;
			var shareTxt = shareTxtArray[randInt];
			wx.ready(function(){
				    // 获取“分享到朋友圈”按钮点击状态及自定义分享内容接口
				    var link = window.location.href;
				    wx.onMenuShareTimeline({
				        title: shareTxt, // 分享标题
				        link: link,
				        imgUrl: imgUrl, // 分享图标
				        success: function () { 
		       				// 用户确认分享后执行的回调函数
		   				},
					    cancel: function () { 
					        // 用户取消分享后执行的回调函数
					    }
				    });
				    // 获取“分享给朋友”按钮点击状态及自定义分享内容接口
				    wx.onMenuShareAppMessage({
				        title: shareTxt, // 分享标题
				        desc: title, // 分享描述
				        link:link,
				        imgUrl: imgUrl, // 分享图标
				        type: 'link', // 分享类型,music、video或link，不填默认为link
				        dataUrl: '',
				        success: function () { 
		       				// 用户确认分享后执行的回调函数
		   				},
					    cancel: function () { 
					        // 用户取消分享后执行的回调函数
					    }
				    });
			});
		}
	};
}();
Mobile.init();