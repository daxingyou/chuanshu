/**
 * lobby.wheel v1.0 $ anther caiyong $ date 2015-02-26
 * 
 */

$(document).ready(function() {
	var ua = window.navigator.userAgent.toLowerCase(); 
	if (ua.match(/MicroMessenger/i) == 'micromessenger') {
		var pageUrl = window.location.href.split('#')[0];
		$.ajax({
			url : "http://wap.mm.pook.com/weixin/getInfo.do",
			type : "post",
			dataType : "json",
			data : {
				"pageUrl" : pageUrl
			},
			success : function(data) {
				if (data == null || data.length == 0) {
					return;
				}
				var jsonInfo = eval(data);
				wx.config({
					debug : false,
					appId : jsonInfo.appid,
					timestamp : jsonInfo.timestamp,
					nonceStr : jsonInfo.nonceStr,
					signature : jsonInfo.signature,
					jsApiList : [ 
					    'onMenuShareTimeline',
						'onMenuShareWeibo', 
						'onMenuShareAppMessage' 
					]
				});
			}
		});
	}
});
