var games = new Map();
var connector = "-";
var default_apk = $("#androidUrl").val();
var android_share_apk = $('#androidShareUrl').val();
var dafault_ios ="http://itunes.apple.com/cn/app/id434811130#weixin.qq.com"; 
var platform_ios = 1;
var platform_ipad = 2;
var platform_andriod = 0;
/**
 * 
 * platform_type 
 * 	0 : andriod
 *  1 : ios
 *  2 : ipad 
 * 
 * game_id 
 * 	21 : ddz
 * 
 */

var GameId = {
	'ddz':21,	
	'lzmj':17,
	'dzpk':38,
	'hlddz':41,
	'srddz':52,
	'djddz':29,
	'gbmj':99,
	'jjdz':63,
	'jjjh':66,
	'gp':57,
	'zgxq':35,
	'blkb':100,
	'hlby':247,
	'hltb':77,
	'qpby':49
};





var GameInfo = {
		init : function(if_share) {
			//初始化微信div
			div.init();
			//下载滚动条
			scrollInit();
			//初始化滚动条
			 if($(document).scrollTop() >= $(document).height() - $(window).height()){
					$(".btn_download_big").css("bottom","0%");
			 }
			var download_apk = default_apk;
			if (if_share != null && if_share == 'true') {
				download_apk = android_share_apk;
			}
			 
			// 大厅下载地址设置
			games.put(GameId.ddz + connector + platform_ios, dafault_ios);
			games.put(GameId.ddz + connector + platform_ipad, dafault_ios);
			games.put(GameId.ddz + connector + platform_andriod, download_apk);
			 
		},
		download : function(gameId) {
			if(Webkit.isWenxin()){ 
				div.show();
				return;
			}
			var type = GameInfo.getType();
			var key = gameId + connector + type;
			var download = games.get(key);
			if(download == ''){
				//alert("该游戏不支持此机型，敬请期待！");
				//return;
				window.location.href = default_apk;
			}
			window.location.href=download;		
		}, 
		getType : function() {
			if (Webkit.isAndroid()) {
				return platform_andriod;
			} else if (Webkit.isIos()){
				return platform_ios;
			} else if (Webkit.isPad()) {
				return platform_ipad;
			} else {
				return platform_andriod;
			}
		}
};

$(function() {
	var if_share = request.QueryString("if_share");
	//初始化游戏信息
	GameInfo.init(if_share);
	$("#download_box").click(function(){
	 	 div.close();
    });
	
	// 设置返回是分享的参数
	if (if_share != null && if_share == 'true') {
		var return_href = $(".return").attr("href")+"?if_share=true";
		$(".return").attr("href", return_href);
	}
});

/**
 * 分享到QQ空间
 */
function ShareTofriends() {
	jiathis_sendto('qzone');
};

/**
 * 初始化滚动条下载
 */
function scrollInit(){
	$(window).scroll(function(){
		$(".download_popup").css("top",$(this).scrollTop()+$(window).height()/3); 
		if($(document).scrollTop()+$(".btn_download_big").height() >= $(document).height() - $(window).height()){
			$(".btn_download_big").css("bottom","0%");
		}else{
			$(".btn_download_big").css("bottom","0");
		}
	});
}

//判断访问终端
var browser = {
	versions: function () {
		var u = navigator.userAgent, app = navigator.appVersion;
		return {
			trident: u.indexOf('Trident') > -1, //IE内核
			presto: u.indexOf('Presto') > -1, //opera内核
			webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
			gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,//火狐内核
			mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
			ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
			android: u.indexOf('Android') > -1 || u.indexOf('Adr') > -1, //android终端
			iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器
			iPad: u.indexOf('iPad') > -1, //是否iPad
			webApp: u.indexOf('Safari') == -1, //是否web应该程序，没有头部与底部
			weixin: u.indexOf('MicroMessenger') > -1, //是否微信 （2015-01-22新增）
			qq: u.match(/\sQQ/i) == " qq" //是否QQ
		};
	}(), language: (navigator.browserLanguage || navigator.language).toLowerCase()
}
