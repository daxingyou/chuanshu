(function() {
	function async_load(){
		var baidu_async = document.createElement('script');
		baidu_async.type = 'text/javascript';
		baidu_async.async = true;
		var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
		baidu_async.src = _bdhmProtocol+unescape('hm.baidu.com/h.js%3F309415d004bef7349917070135831e49');		
		document.body.appendChild(baidu_async);
	}
	
	if (window.attachEvent){
		window.attachEvent('onload', async_load);
	}else{
		window.addEventListener('load', async_load, false);
	}
})();