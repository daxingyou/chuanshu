﻿var langList = 
[
	{name:'en',	charset:'UTF-8'},
	{name:'zh-cn',	charset:'utf-8'},
	{name:'zh-tw',	charset:'GBK'}
];

var skinList = 
[
	{name:'default',	charset:'utf-8'},
	{name:'whyGreen',	charset:'utf-8'}
];