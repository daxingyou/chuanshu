﻿var regtype = 0;
var vali = new HtmlValidate("btnSubmit", OnSubmit);

var nameindex1 = vali.AddTextBoxRequired("txtUserName", "spanUserName", "游戏帐号", 12, 6);
var nameindex2 = vali.AddTextBoxRegular("txtUserName", "spanUserName", "游戏帐号", "(?=.*[a-zA-Z])[0-9a-zA-Z]{6,12}", IsEtis);

//vali.AddTextBoxRequired("txtNickName", "spanNickName", "昵称", 12, 2);

vali.AddTextBoxRequired("txtPassword", "spanPassword", "登录密码", 16, 6);
vali.AddCompare("txtPassword", "txtPassword2", "spanPassword2", "两次输入的密码不一致！", 1);

vali.AddTextBoxRequired("txtTrueName", "spanTrueName", "真实姓名", 12, 2);
vali.AddTextBoxRequired("txtIDC", "spanIDC", "身份证号码");
vali.AddIDCardValidate("txtIDC", "spanIDC");

vali.AddTextBoxRequired("txtValidate", "spanValidate", "验证码", 4, 4);
vali.AddCustomValidate("cbxEnable", "spanEnable", "您是否同意我们的服务协议？", function () { return document.getElementById("cbxEnable").checked; });
vali.Run();


$(function () {
	$("#btnPhoneValidate").ClickToSentSM();
});

function toggleRegType(obj) {
	var $this = $(obj), type = $(".reg-toggle li").index($this);
	$(".reg-toggle li").removeClass("on");
	if (type == 0) {
		regtype = 0;
		$this.addClass("on");
		//$this.css("background", "url('/images/web/btn_reg_normal_1.png')");
		//$this.next().css("background", " url('/images/web/btn_reg_phonenum_2.png')");

		var fobj1 = HtmlValidate.prototype.ObjCollect[nameindex1];
		fobj1.o = "txtUserName";
		fobj1.m = "spanUserName";
		fobj1.mt = "游戏帐号";
		fobj1.xl = 12;
		fobj1.il = 6;
		var fobj2 = HtmlValidate.prototype.ObjCollect[nameindex2];
		fobj2.o = "txtUserName";
		fobj2.m = "spanUserName";
		fobj2.mt = "游戏帐号";
		fobj2.rule = "(?=.*[a-zA-Z])[0-9a-zA-Z]{6,12}";
		$("#txtPhoneNum").unbind();
		vali.BindBlur(fobj1);
		vali.BindBlur(fobj2);

		var usertr = $("#txtUserName").closest("tr");
		usertr.show(); usertr.next().show();
		var phonetr = $("#txtPhoneNum").closest("tr");
		phonetr.hide(); phonetr.next().hide();
		//$("#txtPhoneNum").val("");
		//$("#spanPhoneNum").html("");
		$("#lbValidateText").text("验证码");
		$("#imgValidate").show();
		$("#btnPhoneValidate").hide();
		$("#aChangeValidate").show();
	}
	else {
		regtype = 1;
		//$this.css("background", "url('/images/web/btn_reg_phonenum_1.png')");
		//$this.prev().css("background", " url('/images/web/btn_reg_normal_2.png')");
		$this.addClass("on");
		var fobj1 = HtmlValidate.prototype.ObjCollect[nameindex1];
		fobj1.o = "txtPhoneNum";
		fobj1.m = "spanPhoneNum";
		fobj1.mt = "手机号";
		fobj1.xl = 11;
		fobj1.il = 11;
		var fobj2 = HtmlValidate.prototype.ObjCollect[nameindex2];
		fobj2.o = "txtPhoneNum";
		fobj2.m = "spanPhoneNum";
		fobj2.mt = "手机号";
		fobj2.rule = "^13[0-9]{9}|15[012356789][0-9]{8}|18[023456789][0-9]{8}|147[0-9]{8}$";
		$("#txtUserName").unbind();
		vali.BindBlur(fobj1);
		vali.BindBlur(fobj2);

		var usertr = $("#txtUserName").closest("tr");
		usertr.hide(); usertr.next().hide();
		var phonetr = $("#txtPhoneNum").closest("tr");
		phonetr.show(); phonetr.next().show();
		//$("#txtUserName").val("");
		//$("#spanUserName").html("");
		$("#lbValidateText").text("手机验证码");
		$("#imgValidate").hide();
		$("#btnPhoneValidate").show();
		$("#aChangeValidate").hide();
	}
}

//提交按钮事件
function OnSubmit() {
	$("#btnSubmit").css("display", "none");
	$("#btnReset").css("display", "none");
	$("#btnSubmit").after("<span id='spanLoading'>" + LOADING_ICON + "正在提交您的数据，请稍候..." + "</span>");

	$.post(
	"/Members/MembersHandler.ashx?action=reg&x=" + Math.random(),
		    {
		    	regtype: regtype,  //注册类型：0 普通注册，1 手机注册
		    	username: $("#txtUserName").val().Trim(),
		    	phone: $("#txtPhoneNum").val().Trim(),
		    	nickname: $("#txtNickName").val().Trim(),
		    	password: $("#txtPassword").val().Trim(),
		    	truename: $("#txtTrueName").val().Trim(),
		    	sex: $("input[name=sex]:checked").val().Trim(),
		    	idc: $("#txtIDC").val().Trim(),
		    	validate: $("#txtValidate").val().Trim(),
		    	//以下为非必填项
		    	domainname: domainname,
		    	pageid: pageid,
		    	fromId: fromId,
		    	playerId: playerId,
		    	p1: p1,
		    	p2: p2,
		    	promoter: $("#txtPromoter").val().Trim()

		    },
		    function (data) {
		    	if (data.match("^\{(.+:.+,*){1,}\}$")) {
		    		$("#spanLoading").remove();
		    		data = JSON.parse(data);
		    		ShowRegSucc(data.username, data.givebeans);
		    		//alert("注册成功！");
		    		//location.href = "/Down.aspx";
		    	}
		    	else {
		    		$("#spanLoading").remove();
		    		$("#btnSubmit").css("display", "inline");
		    		$("#btnReset").css("display", "inline");
		    		alert("注册发生错误，错误信息：\r\n" + data, 300);
		    		$("#imgValidate").attr("src", '/Public/Validate.ashx?x=' + Math.random());
		    	}
		    }
	    );
}


function IsEtis() {
	$.post(
		    "/Members/MembersHandler.ashx?action=isusername&x=" + Math.random(),
		    {
		    	username: regtype == "0" ? $("#txtUserName").val().Trim() : $("#txtPhoneNum").val(),
		    	type: "1"
		    },
		    function (data) {
		    	var spantip = regtype == "0" ? $("#spanUserName") : $("#spanPhoneNum");
		    	if (data != "success") {
		    		spantip.html("<span style=\"color:red;font-weight:bold;\">" + data + "</span>");
		    		if (regtype != "0") $("#btnPhoneValidate").attr("disabled", "disabled").removeClass("btn-phonevalid-enable").addClass("btn-phonevalid-disabled");
		    	}
		    	else {
		    		if (regtype != "0" && $("#btnPhoneValidate").attr("ct") != "1") $("#btnPhoneValidate").removeAttr("disabled").removeClass("btn-phonevalid-disabled").addClass("btn-phonevalid-enable");
		    	}
		    }
	    );
}


function IsBadWord() {
	var limitlength = $("#txtNickName").val().Trim().replace(/[^\x00-\xff]/g, "**").length;
	if (limitlength > 12) {
		document.getElementById("spanNickName").innerHTML = "<span style=\"color:red;font-weight:bold;\">昵称2到12字节！</span>";
	}
	else {
		$.post(
			"/Members/MembersHandler.ashx?action=isusername&x=" + Math.random(),
			{
				nickname: escape($("#txtNickName").val().Trim()),
				type: 2
			},
			function (data) {
				if (data == "success") {
					document.getElementById("spanNickName").innerHTML = "<span style=\"color:green;\">昵称可以使用！</span>";
				} else {
					document.getElementById("spanNickName").innerHTML = "<span style=\"color:red;font-weight:bold;\">" + data + "</span>";
				}

			}
		);
	}
}

(function ($) {
	$.fn.ClickToSentSM = function (option) {
		this.option = {
			url: "/Members/MembersHandler.ashx?action=sendphoneregsm",
			phoneId: "txtPhoneNum",
			timeCount: 120
		}
		option = $.fn.extend(this.option, option);
		var $this = $(this), btnText = $this.val(), timer;
		$this.click(function () {
			var phone = $("#" + option.phoneId).val();
			if (phone == "") {
				alert("请输入手机号");
				return;
			}
			if (!/^13[0-9]{9}|15[012356789][0-9]{8}|18[023456789][0-9]{8}|147[0-9]{8}$/.test(phone)) {
				alert("手机号格式不正确");
				return;
			}
			$.get(option.url + "&r=" + Math.random(), { phone: phone }, function () {
				CountDown();
			});
		});
		function CountDown() {
			$this.attr({ "disabled": "disabled", "ct": "1" }).removeClass("btn-phonevalid-enable").addClass("btn-phonevalid-disabled");;
			var time = option.timeCount;

			$this.val("验证码已发送。" + time + "秒");
			timer = setInterval(function () {
				time--;
				if (time > 0) {
					$this.val("验证码已发送。" + time + "秒");
				} else {
					Reset();
				}
			}, 1000);
		};
		function Reset() {
			$this.val(btnText);
			$this.removeAttr("disabled").removeAttr("ct").removeClass("btn-phonevalid-disabled").addClass("btn-phonevalid-enable");;
			clearInterval(timer);
		}
	};
})(jQuery);

function ShowRegSucc(username, givebeans) {
	var shade = $('<div class="reg-succ-shade"></div>').css("height", $(document).height());
	var wframe = '<div class="reg-succ-frame"><div class="top"><a href="/Members/"></a></div><div class="title"></div><div><div class="content">游戏帐号：<label>' + username + '</label></div></div>' +
        '<p class="tip">注册即送<i>' + givebeans + '</i>金豆，登录游戏大厅直接领取</p><div class="down"><a href="/DownURL.aspx?fromid=0&agencyid=1&pageid=1&playerid=0"></a></div></div>';
	var body = $("body"); body.find(".reg-succ-shade").remove(); body.find(".reg-succ-frame").remove();
	body.append(shade).append(wframe);
}