﻿var _hmt = _hmt || [];
(function () {
	var hm = document.createElement("script");
	hm.src = "//hm.baidu.com/hm.js?50adbb3d3dd135d643c992c2eaf1d661";
	var s = document.getElementsByTagName("script")[0];
	s.parentNode.insertBefore(hm, s);
})();