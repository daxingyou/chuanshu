﻿/*

说明： 用户文本框输入提示

*/

//window.onload = function () {
//    var link = document.createElement("link");
//    link.setAttribute("type", "text/css");
//    link.setAttribute("rel", "stylesheet");
//    link.setAttribute("href", "/Js/prompt/css/layout.css");
//    document.getElementsByTagName("head")[0].appendChild(link);
//}


//对象
var oTip = function (name, isattr, attrname, msg) {
    //要谈气泡的对象ID
    this.name = name,
    //显示值是否来自属性,默认不是属性
    this.isAttr = isattr;
    //属性的名称
    this.attrName = attrname,
    //在不是属性的时候，需要提示的内容
    this.msg = msg,
    //函数初始化
    this._Init = oTipInit
};

function oTipInit(e) {
    //未能找到要初始化的对象
    if (this.name.Trim() == "") { throw new Error("未能找到要初始化的对象"); }
    //对象不存在
    if (!$("#" + this.name)) { throw new Error("对象不存在！"); }
    //获取
    if (this.isAttr) {
        this.msg = $("#" + this.name).attr(this.attrName);
    }

    //初始化提示html
    var divHtml = "";
    //    if (!$("#tooltip_" + this.name)) {
    //初始化提示html
    divHtml = "<div class=\"tooltip\" id=\"tooltip_" + this.name + "\">"
                 + "<div class=\"tooltip_bottom\"></div>"
                 + "<div class=\"tooltip_main\" id=\"tooltip_m_" + this.name + "\">" + this.msg + "</div>"
                 + "<div class=\"tooltip_top\"></div>"
                 + "</div>";
    //    }
    //    else 
    //    {
    //        $("#tooltip_m_" + this.name).innerText(this.msg)
    //    }
    //追加提示内容html
    $("#" + this.name).after(divHtml);
    //获取触发对象的相对位置
    var offset = $("#" + this.name).offset();
    offset.left -= 30;
    offset.top += 15;
    //控制位置
    $("#tooltip_" + this.name).css({ "left": offset.left, "top": offset.top });
    $("#tooltip_" + this.name).click(function () {
        $(this).hide();
        $("#" + this.name).focus();
    })
    //控制显示
    $("#" + this.name).focus(function () {
        $("#tooltip_" + this.name).show();
    }).blur(function () {
        $("#tooltip_" + this.name).hide();
    })
}