﻿/*
Create:i@lishilin.cc 2009-09-21
Description:本js文件为后台提供各种操作方法
*/
//后台专用的浮动编辑层
 
function EditLayer(text, width){
	var s = new Screen();
	//创建遮罩层
	var mask = $("#Mask");
	if(mask.length == 0)
	{
		mask = CreateStateDiv2("Mask");
		mask.style.border = "0px";
		mask.style.filter = "alpha(opacity=80)";
		mask.style.opacity = "1";
		mask.style.zIndex = "10000";
		mask.style.backgroundImage = "url(/images/web/xiao_zd.png)";
		mask.style.position = "absolute";
		mask.style.top = 0;
		mask.style.left = 0;
		mask.style.width = "100%";
		mask.style.height = Math.max(s.ClientHeight,s.ScrollHeight) + "px";
		mask.style.display = "inline";
		$(mask).css("-moz-opacity","0.8");
		$(mask).click(function(){ CloseLayer(); });
		AppendElement(mask);
	}
	else
	{
		mask.css("display","inline");
	}

	var state = $("#Tranning")[0];
	if (state == null) {
		state = CreateStateDiv2("Tranning");
		AppendElement(state);
	}
	var swidth = (width == null || width == "" || width == 0) ? 600 : width;

	var content = [
	'<span style="position: absolute; top: 4px; right: 0px;">',
	'<img src="/images/web/xiao_an_10.png" width="38" height="37" onmouse style="border: 0; margin-right:20px; margin-top:20px; cursor:pointer;" title="关闭" alt="关闭" onclick="CloseLayer();" /></span>',
	text].join("");
	//var content = [text].join("");
	
	$(state).css("display","inline").css("width",swidth + "px");
	$(state).html(content);

	var stop = s.ScrollTop + (s.ClientHeight - 430) / 2;
 
	if(stop < 0)
		stop = 20;
	var sleft = s.ScrollLeft + ((s.ClientWidth - width) / 2);
	if(sleft < 0)
	    sleft = 20;
	 
	$(state).css("top", stop).css("left",sleft)
}

//全局变量RefreshPage定义关闭弹出层时是否刷新页面
var RefreshPage = false;

//关闭弹出层
function CloseLayer()
{
	HiddenState("Mask", 1);
	HiddenState("Tranning", 1);
	if(RefreshPage)
		location.href=location.href;
}

//检测页面是否已定义ActionUrl和Target变量
function CheckDefine()
{	
	if(ActionUrl == null || ActionUrl == 'undefine' || ActionUrl == "")
	{
		//Msg("请定义ActionUrl变量！",300);
		return false;
	}
	if(Target == null || Target == 'undefine' || Target == "")
		Target = "_blank";
	if(DialogWidth == null || DialogWidth == 'undefine' || DialogWidth == 0)
		DialogWidth = 500;
	if(DialogHeight == null || DialogHeight == 'undefine' || DialogHeight == 0)
		DialogHeight = 400;
	return true;
}

//修改数据按钮的方法
function Edit(intid) {
    if (!CheckDefine())
        return;
    
    var list = intid;
    var url = SetUrlParam(ActionUrl, "params=" + list.toString());

    if (Target.toLowerCase() == "_blank") {
    
        url = SetUrlParam(url, "reurl=" + encodeURIComponent(location.href));
        LocationTo(url);

    }
    else {

    	EditLayer("<iframe src='" + url + "' height='" + DialogHeight + "' width='" + DialogWidth + "' border='0' frameborder='0'  allowTransparency='true' scrolling='no' />", DialogWidth);
    }
}
function Screen() {
    this.ScrollTop = document.body.scrollTop || document.documentElement.scrollTop || 0; //网页被卷去的高
    this.ScrollLeft = document.documentElement.scrollLeft; //网页被卷去的左
    this.ScrollWidth = document.documentElement.scrollWidth; //网页正文全文宽
    this.ScrollHeight = document.documentElement.scrollHeight; //网页正文全文高
    this.ClientHeight = document.documentElement.clientHeight; //网页可见区域高
    this.ClientWidth = document.documentElement.clientWidth; //网页可见区域宽
    this.OffsetWidth = document.documentElement.offsetWidth; //网页可见区域宽(包括边线)
    this.OffsetHeight = document.documentElement.offsetHeight; //网页可见区域高(包括边线)
    this.ScreenTop = window.screenTop; //网页正文部分上
    this.ScreenLeft = window.screenLeft; //网页正文部分左
    this.ScreenHeight = window.screen.height; //屏幕分辨率的高
    this.ScreenWidth = window.screen.width; //屏幕分辨率的宽
    this.AvailHeight = window.screen.availHeight; //屏幕有效工作区高
    this.AvailWidth = window.screen.availWidth; //屏幕有效工作区宽
}


//修改数据按钮的方法2
function Edit2(intid) {
    if (!CheckDefine())
        return;

    var list = intid;
    var url = SetUrlParam(ActionUrl, "gid=" + list.toString());

    if (Target.toLowerCase() == "_blank") {

        url = SetUrlParam(url, "reurl=" + encodeURIComponent(location.href));
        LocationTo(url);

    }
    else {

    	EditLayer("<iframe src='" + url + "' height='" + DialogHeight + "' width='" + DialogWidth + "' border='0' frameborder='0'  allowTransparency='true' scrolling='no' />", DialogWidth);
    }
}


function CreateStateDiv2(divID) {
    var div = document.createElement("div");
    div.id = divID;
    with (div.style) {
        fontSize = "12px";
       // background = "url(/images/web/xiao_zd.png)";
        border = "0px";
        position = "absolute";
        zIndex = "100000";
        display = "none";
    }
    return div;
}


