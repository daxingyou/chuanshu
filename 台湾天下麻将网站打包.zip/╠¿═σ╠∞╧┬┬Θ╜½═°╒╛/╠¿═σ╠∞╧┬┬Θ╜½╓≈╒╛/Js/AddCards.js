﻿

var ProvinceList=[
["11","北京市"],
["12","天津市"],
["13","河北省"],
["14","山西省"],
["15","内蒙古自治区"],
["21","辽宁省"],
["22","吉林省"],
["23","黑龙江省"],
["31","上海市"],
["32","江苏省"],
["33","浙江省"],
["34","安徽省"],
["35","福建省"],
["36","江西省"],
["37","山东省"],
["41","河南省"],
["42","湖北省"],
["43","湖南省"],
["44","广东省"],
["45","广西壮族自治区"],
["46","海南省"],
["50","重庆市"],
["51","四川省"],
["52","贵州省"],
["53","云南省"],
["54","西藏自治区"],
["61","陕西省"],
["62","甘肃省"],
["63","青海省"],
["64","宁夏回族自治区"],
["65","新疆维吾尔自治区"],
["71","台湾"],
["81","香港特别行政区"],
["82","澳门特别行政区"]
];
var LetterList=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
var CardType=[
["A","实物卡"],
["B","虚拟卡"],
["C","礼品卡"]
];
var PresentType=[
["1","网吧派送"],
["2","玩家购买"],
["3","活动赠送"],
["4","比赛奖品"]
];
var Month=[
["Z","临时卡"],
["A","01月"],
["B","02月"],
["C","03月"],
["D","04月"],
["E","05月"],
["F","06月"],
["G","07月"],
["H","08月"],
["I","09月"],
["J","10月"],
["K","11月"],
["L","12月"]
];


//绑定省份
//参数：
function BindProvince(provinceID,hiddenPid,isShowNone)
{
	var province = $("#" + provinceID);
	var hidp = $("#" + hiddenPid);

	//清空省份控件
	province.html("")
	
	//设置初始项
	if( isShowNone )
		province.append("<option value='none'>== 请选择省份 ==</option>");
	//绑定省份数据
	for(var i=0;i<ProvinceList.length;i++){
		if(ProvinceList[i] != null){
			var html = "<option ";
			if(((hidp.val()==""||hidp.val()==null)&&i==0&&(!isShowNone)) || (hidp.val() == ProvinceList[i][1] || hidp.val() == ProvinceList[i][0])){
				html+="selected='selected' ";
				hidp.val(ProvinceList[i][0]);				
			}
			html+="value='"+ProvinceList[i][0]+"'>"+ProvinceList[i][1]+"</option>";
			province.append(html);
		}
	}
	//省份选择事件
	province.change(
		function(){
			var thisval = $(this).find("option:selected").val();
			if(thisval == "none"){
				hidp.val("");
			}
			else{
				hidp.val($(this).find("option:selected").val());
			}
		}
	);

}
//绑定
function BindLetter(area)
{
	var letter = $( "#" + area );
	letter.html("");
	for(var i=0;i<LetterList.length;i++)
	{
		var html="<option ";
		html+="value='"+LetterList[i]+"'>"+LetterList[i]+"</option>";
		letter.append(html);
	}
}
//绑定点卡类型
function BindCardType(type)
{
	var type = $( "#" + type );
	type.html("");
	for(var i=0;i<CardType.length;i++)
	{
		var html="<option ";
		html+="value='"+CardType[i][0]+"'>"+CardType[i][1]+"</option>";
		type.append(html);
	}
	type.change(function(){
		var thisval=$(this).find("option:selected").val();
		if(thisval!="")
			$("#div"+thisval).show().siblings().hide();
		/*if(thisval=="A"){
			$("#TC").show();
			$("#VC").hide();
			$("#GC").hide();
		}
		else if(thisval=="B"){
			$("#TC").hide();
			$("#VC").show();
			$("#GC").hide();
		}
		else if (thisval=="C"){
			$("#TC").hide();
			$("#VC").hide();
			$("#GC").show();
		}*/
		
	});
}
//绑定点卡派送渠道
function BindPresentType(ptype)
{
	var ptype = $( "#" + ptype );
	ptype.html("");
	for(var i=0;i<PresentType.length;i++)
	{
		var html="<option ";
		html+="value='"+PresentType[i][0]+"'>"+PresentType[i][1]+"</option>";
		ptype.append(html);
	}
}
//绑定月份
function BindMonth(month)
{
	$("#txtNum").attr("readonly","readonly").val("0");
	var m = $( "#" + month );
	m.html("");
	for(var i=0;i<Month.length;i++)
	{
		var html="<option ";
		html+="value='"+Month[i][0]+"'>"+Month[i][1]+"</option>";
		m.append(html);
	}
	m.change(function(){
		var ival=$(this).find("option:selected").val();		
		if(ival=="Z")			
			$("#txtNum").attr("readonly","readonly").val("0");
		else
			$("#txtNum").removeAttr("readonly");
	});
}