﻿$(window).resize(function () {
	var height = $(".main_bd").get(0).clientHeight;
	$(".Mian").height(height);
	$(".txtDiv").height(height * 0.2);
});

$(function () {
	$(".select3").uedSelect({ width: "100%" });
	var height = $(".main_bd").get(0).clientHeight;
	$(".Mian").height(height);
	$(".txtDiv").height(height * 0.2);

	//选择购买/寄售/记录
	$(".btn-title").click(function () {
		$(this).parent().children().removeClass("on");
		$(this).addClass("on");
		var name = $(this).attr("name");
		if ($(".btn-title").index(this) == 0) {
			$(".search").show();
		}
		else {
			$(".search").hide();
		}
		changeDiv(name);
	});
	//选择类型
	$(".btn").click(function () {
		var $this = $(this), $divs = $this.parent().children();
		$divs.removeClass("on");
		$this.addClass("on");
		var name = $this.attr("name");

		switch (currindex()) {
			case 0: {
				var sallerid = $("#txtKey").val();
				sallerid = sallerid.trim() == "" || isNaN(sallerid) ? 0 : sallerid;
				fillgoodslist($(this).attr("kindid"), sallerid);
			} break;
			case 2: {
				var index = $divs.index($this);
				$("#thUserName").text(index == 0 ? "寄售人" : "购买人");
				$("#thRecordTime").text(index == 0 ? "购买时间" : "售出时间");
				fillgoodsrecord(index);
			} break;
		}

	});

	//搜索
	$("#searchImg").click(function () {
		loadgoodslist();
	}).trigger("click");

	$("#select_k1").change(function (e) {
		$.get("SalesService.ashx?method=mypropcount&r=" + Math.random(), { propid: e.target.value }, function (data) {
			data = JSON.parse(data);
			if (data.code == 1) {
				$("#spanCurrentAmount").text(data.carrier);
			}
			else {
				ShowTip(data.message);
			}
		});
	});

});

///点击按钮内容切换
function changeDiv(name) {
	init(name);
	switch (name) {
		case "buyDiv":
			$("#Tab_Buy").show();
			$("#Tab_Sale").hide();
			$("#Tab_Record").hide();
			loadgoodslist();
			break;
		case "saleDiv":
			$("#Tab_Buy").hide();
			$("#Tab_Sale").show();
			$("#Tab_Record").hide();
			fillmygoodslist();
			break;
		case "RecordDiv":
			$("#Tab_Buy").hide();
			$("#Tab_Sale").hide();
			$("#Tab_Record").show();
			loadgoodsrecord();
			break;
		default:
			break;
	}
}

//按钮隐藏显示切换
function init(name) {
	$("#daliogDiv").hide();
	if (name == "buyDiv") {
		$("#left-Buy").show();
		$("#left-Record").hide();
		$("#left-Sale").hide();
	}
	else if (name == "saleDiv") {
		$("#left-Buy").hide();
		$("#left-Record").hide();
		$("#left-Sale").show();
	}
	else if (name == "RecordDiv") {
		$("#left-Buy").hide();
		$("#left-Record").show();
		$("#left-Sale").hide();
	}
}

function currindex() {
	var tbtns = $(".btn-title");
	for (var i = 0; i < tbtns.length; i++) {
		if ($(tbtns[i]).hasClass("on")) return tbtns.index(tbtns[i]);
	}
	return 0;
}

function loading($table) {
	$table.empty().append("<tr class=\"bakimg\"><td>&nbsp;</td><td colspan=\"4\"><img style=\"width:5%;vertical-align:middle;\" src=\"../../Images/Hall/auctionhouse/moblie/loading.gif\" /><span style=\"margin-left:1%;vertical-align:middle;\">努力加载中...</span></td><td style=\"width: 1%\"><div style=\"padding-bottom: 800%\"></div></td><td>&nbsp;</td></tr>");
}

function nodata($table) {
	$table.empty().append("<tr class=\"bakimg\"><td>&nbsp;</td><td colspan=\"4\">没有找到相关信息</td><td style=\"width: 1%\"><div style=\"padding-bottom: 800%\"></div></td><td>&nbsp;</td></tr>");
}

function loadgoodslist() {
	var kindid = $("#left-Buy").find(".on").attr("kindid");
	var sallerid = $("#txtKey").val();
	sallerid = sallerid.trim() == "" || isNaN(sallerid) ? 0 : sallerid;
	if (isNaN(sallerid)) {
		ShowTip("卖家ID请输入数字"); return;
	}
	fillgoodslist(kindid, sallerid);
}

function fillgoodslist(kindid, sallerid) {
	var $table = $("#Tab_Buy").find(".ContentDiv table");
	loading($table);
	$.get("SalesService.ashx?method=goodslist&r=" + Math.random(), { kindid: kindid, goodsid: 0, sallerid: sallerid }, function (data) {
		data = JSON.parse(data);
		if (data.code == 1) {
			filltable($table, data.carrier);
			$(".ImgBtnBuy").click(function () {
				var $this = $(this), id = $this.attr("glid");
				var cost = $this.parent().prev().text();
				if (isGuest == "1") {
					confirmTip("确定花费" + cost + "金豆购买该商品？", function () { buyoperator(id, false); });
				}
				else {
					confirmTip("确定花费" + cost + "金豆购买该商品？", function () { buyoperator(id, true); });
					$("#pwdDiv").show();
				}
			});
		}
		else {
			ShowTip(data.message);
		}
	});
}

function buyoperator(id, checkpass) {
	var pass = $("#PassWord").val();
	if (checkpass && (!pass || pass == "")) {
		ShowTip("银行密码不正确");
		return;
	}
	$.post("SalesService.ashx?method=buygoods&r=" + Math.random(), { id: id, pass: pass }, function (data) {
		if (data != "") {
			data = JSON.parse(data);
			if (data.code == 0) {
				loadgoodslist();
			}
			ShowTip(data.message);
		}
	});
	$("#PassWord").val("");
}

function fillmygoodslist() {
	var $table = $("#Tab_Sale").find(".ContentDiv table");
	loading($table);
	$.get("SalesService.ashx?method=mygoodslist&r=" + Math.random(), function (data) {
		data = JSON.parse(data);
		if (data.code == 1) {
			filltable($table, data.carrier);
			$table.find(".soldOut").click(function () {   //绑定下架事件
				var $this = $(this);
				pushoffsale($this.attr("glid"), $this.closest("tr").children(":first").text())
			});
		}
		else {
			$table.empty();
			ShowTip(data.message);
		}
	});
}

function loadgoodsrecord() {
	var $div = $("#left-Record").find(".on");
	var index = $("#left-Record").children("div").index($div);
	fillgoodsrecord(index);
}

function fillgoodsrecord(type) {
	var $table = $("#Tab_Record").find(".ContentDiv table");
	loading($table);
	$.get("SalesService.ashx?method=salesrecord&r=" + Math.random(), { type: type }, function (data) {
		data = JSON.parse(data);
		if (data.code == 1) {
			filltable($table, data.carrier);
		}
		else {
			$table.empty();
			ShowTip(data.message);
		}
	});
}

function putonsale() {
	var goodsid = $("#select_k1").val();
	if (goodsid < 0) {
		ShowTip("无效的商品");
		return;
	}
	if (!numcheck("txtUnitPrice", "出售单价", true)) {
		return;
	}
	if (!numcheck("txtAmount", "出售数量", true)) {
		return;
	}

	$.get("SalesService.ashx?method=putonsale&r=" + Math.random(),
	    { goodsid: goodsid, unitprice: $("#txtUnitPrice").val(), amount: $("#txtAmount").val(), ptype: 1 },
	    function (data) {
	    	data = JSON.parse(data);
	    	ShowTip(data.message);
	    	if (data.code == 0) {
	    		$("#select_k1").trigger("change");
	    		fillmygoodslist();
	    	}
	    });

}

function pushoffsale(id, gdsname) {
	confirmTip("是否确定对《" + gdsname + "》进行下架？", function () {
		$.get("SalesService.ashx?method=pushoffsale&r=" + Math.random(), { id: id }, function (data) {
			data = JSON.parse(data);
			ShowTip(data.message);
			if (data.code == 0) {
				$("#select_k1").trigger("change");
				fillmygoodslist();
			}
		});
	});
}

function filltable($table, data) {
	$table.empty(); //清空表
	if (data && data.length > 0) {
		var $ths = $table.parent().prev().find("tr>th");
		var $trshtm = "";
		for (var i = 0; i < data.length; i++) {
			$trshtm += "<tr class=\"bakimg\">";
			for (var j = 0; j < $ths.length; j++) {
				var $th = $($ths[j]);
				if ($th.attr("format") == "date") {
					$trshtm += "<td style=\"" + $th.attr("style") + "\" >" + parseToDate(eval("data[i]." + $th.attr("column"))).format("yyyy-MM-dd hh:mm:ss") + "</td>\r\n";
				}
				else if ($th.attr("default")) {
					$trshtm += "<td style=\"" + $th.attr("style") + "\" >" + $th.attr("default").replace("{0}", eval("data[i]." + $th.attr("column"))) + "</td>\r\n";
				} else {
					$trshtm += "<td style=\"" + $th.attr("style") + "\" >" + eval("data[i]." + $th.attr("column")) + "</td>\r\n";
				}
			}
			$trshtm += "</tr>\r\n";
		}
		$table.append($trshtm);
	}
	else {
		nodata($table);
	}
}

function numcheck(id, desc, over0) {
	var num = $("#" + id).val();
	if (!num.length) {
		ShowTip("请输入" + desc);
		return false;
	}
	if (isNaN(num)) {
		ShowTip(desc + "必须为数字");
		return false;
	}
	if (over0 && num <= 0) {
		ShowTip(desc + "必须大于0");
		return false;
	}
	return true;
}

function caculate() {
	var amount = correctnum($("#txtAmount").val()), price = correctnum($("#txtUnitPrice").val());

	$("#spanTax").text(Math.round(amount * price * taxPersent / 100));
	$("#spanGain").text(Math.round(amount * price * (1 - taxPersent / 100)));
}

function correctnum(num) {
	return num == "" || isNaN(num) ? 0 : num;
}

function resetinput() {
	$("#txtAmount").val("");
	$("#txtUnitPrice").val("");
}

//弹框
function confirmTip(msg, OKEvent) {
	ShowTip(msg, OKEvent);
	$(".Btn_Img").removeClass("Btn_Img_Single");
}

function ShowTip(msg, OKEvent) {
	$("#daliogDiv").show();
	$("#pwdDiv").hide();
	$(".Btn_Img").addClass("Btn_Img_Single");
	$(".txtLabel").text(msg)
	if (OKEvent && typeof (OKEvent) == "function") {
		$("#CalBtn").unbind("click").click(function () {
			$("#daliogDiv").hide();
		});
		$("#SureBtn").unbind("click").click(function () {
			OKEvent();
		});
	}
	else {
		$("#SureBtn").unbind("click").click(function () {
			$("#daliogDiv").hide();
		});
	}
}

function parseToDate(value) {
	if (value == null || value == '') {
		return undefined;
	}
	var dt;
	if (value instanceof Date) {
		dt = value;
	}
	else {
		if (!isNaN(value)) {
			dt = new Date(value);
		}
		else if (value.indexOf('/Date') > -1) {
			value = value.replace(/\/Date\((-?[\d|\+]+)\)\//, '$1');
			dt = new Date();
			dt.setTime(parseInt(value));
		} else if (value.indexOf('/') > -1) {
			dt = new Date(Date.parse(value.replace(/-/g, '/')));
		} else {
			dt = new Date(value);
		}
	}
	return dt;
}

Date.prototype.format = function (format) {
	var o = {
		"M+": this.getMonth() + 1, //month   
		"d+": this.getDate(),    //day   
		"h+": this.getHours(),   //hour   
		"m+": this.getMinutes(), //minute   
		"s+": this.getSeconds(), //second   
		"q+": Math.floor((this.getMonth() + 3) / 3),  //quarter   
		"S": this.getMilliseconds() //millisecond   
	};
	if (/(y+)/.test(format))
		format = format.replace(RegExp.$1,
                            (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	for (var k in o)
		if (new RegExp("(" + k + ")").test(format))
			format = format.replace(RegExp.$1,
			    RegExp.$1.length == 1 ? o[k] :
			    ("00" + o[k]).substr(("" + o[k]).length));
	return format;
};