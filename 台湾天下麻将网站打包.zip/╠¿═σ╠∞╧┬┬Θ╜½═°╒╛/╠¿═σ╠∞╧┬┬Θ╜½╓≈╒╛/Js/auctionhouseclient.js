﻿$(function () {
	$(".goodslist").uedSelect({ width: 135 });

	$("#buy_control").find(".menu>li").click(function (e) {
		var $this = $(this);
		var ul = $this.find("ul");
		if (ul.length > 0) {
			if (ul.is(":hidden")) {
				ul.slideDown();
			} else {
				if (e.target == e.currentTarget || $(e.target).closest("li").get(0) == e.currentTarget) {
					ul.slideUp();
				}
				else {
					var $li = $(e.target).is("li") ? $(e.target) : $(e.target).closest("li");
					$this.parent().find("li").removeClass("active");
					$this.addClass("active");
					$li.addClass("active");
					//代码
					fillgoodslist(-1, $li.attr("propid"));
				}
			}
		}
		else {
			$this.parent().find("li").removeClass("active");
			$this.addClass("active");
			//代码
			fillgoodslist($this.attr("kindid"), 0);
		}
	});

	$("#record_control").find("ul>li").click(function () {
		var $this = $(this), $lis = $this.parent().children();
		$lis.removeClass("active");
		$this.addClass("active");
		var index = $lis.index($this);

		$("#thUserName").text(index == 0 ? "寄售人" : "购买人");
		$("#thRecordTime").text(index == 0 ? "购买时间" : "售出时间");
		fillgoodsrecord(index);
	});

	$(".toggle>li").click(function () {
		var $this = $(this);
		if ($this.attr("class").indexOf("active") > -1) return;
		var $lis = $this.parent().children("li");
		$lis.removeClass("active");
		$this.addClass("active");
		var index = $lis.index($this);

		var $leftdivs = $(".left_module").children("div");
		$leftdivs.hide();
		$leftdivs.eq(index).show();

		var $rightdivs = $(".right_container").children("div");
		$rightdivs.hide();
		$rightdivs.eq(index).show();

		switch (index) {
			case 0: {
				loadgoodslist();
				$(".search").show();
			} break;
			case 1: {
				fillmygoodslist();
				$("#ddlEnableSaleGoods").trigger("change");
				$(".search").hide();
			} break;
			case 2: {
				loadgoodsrecord();
				$(".search").hide();
			}
			default: $(".search").hide(); break;
		}
	});

	$("#ddlEnableSaleGoods").change(function (e) {
		$.get("SalesService.ashx?method=mypropcount&r=" + Math.random(), { propid: e.target.value }, function (data) {
			data = JSON.parse(data);
			if (data.code == 1) {
				$("#txtCurrentAmount").val(data.carrier);
			}
			else {
				showTip(data.message);
			}
		});
	});

	loadgoodslist();
});

function loadgoodslist() {
	var $lis = $("#buy_control").find(".menu li[class='active']");
	var propid;
	for (var i = 0; i < $lis.length; i++) {
		propid = $($lis[i]).attr("propid");
		if (propid) break;
	}
	if (propid > 0) {
		fillgoodslist(-1, propid);
	}
	else {
		fillgoodslist($lis.attr("kindid"), 0);
	}
}

function fillgoodslist(kindid, goodsid) {
	var $table = $("#right_ct_buy").find(".scroll_container table");
	loading($table);
	var sallerid = $("#txtSallerID").val();
	sallerid = (sallerid == "" || isNaN(sallerid)) ? 0 : sallerid;
	$.get("SalesService.ashx?method=goodslist&r=" + Math.random(), { kindid: kindid, goodsid: goodsid, sallerid: sallerid }, function (data) {
		data = JSON.parse(data)
		if (data.code == 1) {
			filltable($table, data.carrier);

			$table.find(".buyit").click(function () {   //绑定购买事件
				var $this = $(this);
				buygoods($this.attr("glid"), $this.parent().prev().text())
			});
		}
		else {
			$table.empty();
			showTip(data.message);
		}
	});
}

function fillmygoodslist() {
	var $table = $("#right_ct_sale").find(".scroll_container table");
	loading($table);
	$.get("SalesService.ashx?method=mygoodslist&r=" + Math.random(), function (data) {
		data = JSON.parse(data);
		if (data.code == 1) {
			filltable($table, data.carrier);
			$table.find(".pushoff").click(function () {   //绑定下架事件
				var $this = $(this);
				pushoffsale($this.attr("glid"), $this.closest("tr").children(":first").text())
			});
		}
		else {
			$table.empty();
			showTip(data.message);
		}
	});
}

function loadgoodsrecord() {
	var $li = $("#record_control").find("li[class='active']");
	var index = $("#record_control").find("li").index($li);
	fillgoodsrecord(index);
}

function fillgoodsrecord(type) {
	var $table = $("#right_ct_record").find(".scroll_container table");
	loading($table);
	$.get("SalesService.ashx?method=salesrecord&r=" + Math.random(), { type: type }, function (data) {
		data = JSON.parse(data);
		if (data.code == 1) {
			filltable($table, data.carrier);
		}
		else {
			$table.empty();
			showTip(data.message);
		}
	});
}

function buygoods(id, tprice) {
	var aphtm = $("<div class=\"tip_pass\"><label>银行密码：</label><input type=\"password\" id=\"txtBankPass\" maxlength=\"40\" /></div>");
	confirmTip("是否花费" + tprice + "金豆购买该商品？", function () {
		var pass = aphtm.find("input").val();
		if (pass.length == 0) {
			showTip("请输入银行密码");
			return;
		}
		$.post("SalesService.ashx?method=buygoods&r=" + Math.random(), { id: id, pass: pass }, function (data) {
			data = JSON.parse(data);
			showTip(data.message);
			if (data.code == 0) loadgoodslist();
		});
	}, aphtm);
}

function putonsale() {
	var goodsid = $("#ddlEnableSaleGoods").val();
	if (goodsid < 0) {
		showTip("无效的商品");
		return;
	}
	if (!numcheck("txtUnitPrice", "出售单价", true)) {
		return;
	}
	if (!numcheck("txtAmount", "出售数量", true)) {
		return;
	}

	$.get("SalesService.ashx?method=putonsale&r=" + Math.random(),
	    { goodsid: goodsid, unitprice: $("#txtUnitPrice").val(), amount: $("#txtAmount").val() },
	    function (data) {
	    	data = JSON.parse(data);
	    	showTip(data.message);
	    	if (data.code == 0) {
	    		$("#ddlEnableSaleGoods").trigger("change");
	    		fillmygoodslist();
	    	}
	    });

}

function pushoffsale(id, gdsname) {
	confirmTip("是否确定对《" + gdsname + "》进行下架？", function () {
		$.get("SalesService.ashx?method=pushoffsale&r=" + Math.random(), { id: id }, function (data) {
			data = JSON.parse(data);
			showTip(data.message);
			if (data.code == 0) {
				$("#ddlEnableSaleGoods").trigger("change");
				fillmygoodslist();
			}
		});
	});
}

function loading($table) {
	$table.empty();
	$table.append("<tr><td class=\"loading\"><img src=\"../../Images/Hall/auctionhouse/client/loading.gif\" /><span>努力加载中...</span></td></tr>");
}

function filltable($table, data) {
	$table.empty(); //清空表
	if (data) {
		var $ths = $table.parent().prev().find("tr>th");
		var $trshtm = "";
		for (var i = 0; i < data.length; i++) {
			$trshtm += "<tr>";
			for (var j = 0; j < $ths.length; j++) {
				var $th = $($ths[j]);
				if ($th.attr("format") == "date") {
					$trshtm += "<td width=\"" + $th.attr("width") + "\" >" + parseToDate(eval("data[i]." + $th.attr("column"))).format("yyyy-MM-dd hh:mm:ss") + "</td>\r\n";
				}
				else if ($th.attr("default")) {
					$trshtm += "<td width=\"" + $th.attr("width") + "\" >" + $th.attr("default").replace("{0}", eval("data[i]." + $th.attr("column"))) + "</td>\r\n";
				} else {
					$trshtm += "<td width=\"" + $th.attr("width") + "\" >" + eval("data[i]." + $th.attr("column")) + "</td>\r\n";
				}
			}
			$trshtm += "</tr>\r\n";
		}
		$table.append($trshtm);
	}
}

function confirmTip(msg, okHandlerEvent, aphtm) {
	if (aphtm) {
		$(".tip_content").append(aphtm);
		showTip(msg, true, false);
	}
	else {
		showTip(msg, true);
	}
	$("#btnTipOK").unbind("click").click(function () {
		cancelTip();
		if (aphtm) aphtm.remove();
		if (typeof (okHandlerEvent) == "function") okHandlerEvent();
	});
	$("#btnTipCancel").unbind("click").click(function () {
		cancelTip();
		if (aphtm) aphtm.remove();
	});
}

function showTip(msg, bts, empty) {
	empty = typeof (empty) == "undefined" ? true : empty;
	if (empty) $(".tip_content").empty().append("<p></p>");

	$(".tip_content>p").text(msg);
	if (bts) {
		$("#btnTipOK").unbind("click");
		$("#btnTipCancel").unbind("click").click(function () { cancelTip() });
		$(".tip_buttons").removeClass("tip_button_single");
	}
	else {
		$("#btnTipOK").unbind("click").click(function () { cancelTip() });
		$(".tip_buttons").addClass("tip_button_single");
	}
	$(".tip_shade").fadeIn(100);
	$(".tip").fadeIn(100);
}

function cancelTip() {
	$(".tip_shade").fadeOut(100);
	$(".tip").fadeOut(100);
}

function numcheck(id, desc, over0) {
	var num = $("#" + id).val();
	if (!num.length) {
		showTip("请输入" + desc);
		return false;
	}
	if (isNaN(num)) {
		showTip(desc + "必须为数字");
		return false;
	}
	if (over0 && num <= 0) {
		showTip(desc + "必须大于0");
		return false;
	}
	return true;
}

function caculate() {
	var amount = correctnum($("#txtAmount").val()), price = correctnum($("#txtUnitPrice").val());

	$("#txtTax").val(Math.round(amount * price * taxPersent / 100));
	$("#txtGain").val(Math.round(amount * price * (1 - taxPersent / 100)));
}

function correctnum(num) {
	return num == "" || isNaN(num) ? 0 : num;
}

function resetinput() {
	$("#txtAmount").val("");
	$("#txtUnitPrice").val("");
}

function parseToDate(value) {
	if (value == null || value == '') {
		return undefined;
	}
	var dt;
	if (value instanceof Date) {
		dt = value;
	}
	else {
		if (!isNaN(value)) {
			dt = new Date(value);
		}
		else if (value.indexOf('/Date') > -1) {
			value = value.replace(/\/Date\((-?[\d|\+]+)\)\//, '$1');
			dt = new Date();
			dt.setTime(parseInt(value));
		} else if (value.indexOf('/') > -1) {
			dt = new Date(Date.parse(value.replace(/-/g, '/')));
		} else {
			dt = new Date(value);
		}
	}
	return dt;
}

Date.prototype.format = function (format) {
	var o = {
		"M+": this.getMonth() + 1, //month   
		"d+": this.getDate(),    //day   
		"h+": this.getHours(),   //hour   
		"m+": this.getMinutes(), //minute   
		"s+": this.getSeconds(), //second   
		"q+": Math.floor((this.getMonth() + 3) / 3),  //quarter   
		"S": this.getMilliseconds() //millisecond   
	};
	if (/(y+)/.test(format))
		format = format.replace(RegExp.$1,
                    (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	for (var k in o)
		if (new RegExp("(" + k + ")").test(format))
			format = format.replace(RegExp.$1,
			    RegExp.$1.length == 1 ? o[k] :
				("00" + o[k]).substr(("" + o[k]).length));
	return format;
};