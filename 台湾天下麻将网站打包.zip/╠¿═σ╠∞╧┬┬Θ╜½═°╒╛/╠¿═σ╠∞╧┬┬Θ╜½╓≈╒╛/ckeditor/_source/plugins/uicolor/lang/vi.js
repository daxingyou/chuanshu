﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'uicolor', 'vi',
{
	uicolor :
	{
		title : 'Giao diện người dùng Color Picker',
		preview : 'Xem trước trực tiếp',
		config : 'Dán chuỗi này vào tập tin config.js của bạn',
		predefined : 'Tập màu định nghĩa sẵn'
	}
});
